Bistutu空教室查询
===================

安卓版本。

## 项目简介

本软件适用于北京信息科技大学空教室查询，开发此软件的目的是为了能够帮助热爱学习的小伙伴迅速找到合适的空教室，软件设计理念追求简洁，软件目前正在持续维护中。

## 软件截图 
![](https://i.loli.net/2021/10/23/KQya2HZPYOD3N1E.jpg)

## 使用到的第三方库

```
1. QMUI 界面设计
2. okhttp3 网络请求
3. Gson JSON数据解析
```

## License

```
Copyright 2021, Bistutu

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
```
