package com.thinkstu.myapplication

class empty_list(val a:String,val b:String,val c:String,val d:String) {
}