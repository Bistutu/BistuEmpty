package com.thinkstu.myapplication

class updateObject(val isUpdate:String,val updateMessage:String,val updateUrl:String) {
}